import entorno.Calculadora;

public class GestionCuentas {
    static void main() {
        int num1=3;
        int num2=4;
        Calculadora calculadora =new Calculadora();
        int resultado=calculadora.suma(3,4);
        System.out.println(resultado);
    }
}
