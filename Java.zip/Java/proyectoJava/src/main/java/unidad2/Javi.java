package unidad2;

public class Javi {
    static void main() { //main + enter
        System.out.println("Mi clase"); //sout + enter
        int num1=10;
        int num2=1000;
        int resultado=num1+num2;  //declaro solo una vez el tipo de variable que es, pero simpre hay que ponerlo (int, float...)
        System.out.println(resultado);
        String micadena = "hola mundo";
        System.out.println(micadena);
        boolean encontrado = false;
        if(encontrado) System.out.println("No encontrado");   //en java no es necesaro la tabulación
        else System.out.println("encontrado");  //si quiero que dentro del if o else ejecute muchas cosas lo pongo todo entre {}
        int y=4;
        int z=3;
        int res=y/z-y*z;
        System.out.println(res);



    }
}
