package org.example;
public class Main {
    static void main() {
        System.out.println("Hola");
    }
    }