package org.example;

public class Dia2 {
    static void main() {
        float y=4;
        float z=3;
        float res=y/z-y*z;
        System.out.println(res);

        float x=3;
        float res2=x-3;
        float res3=res2-x;
        System.out.println(res2);
        System.out.println(res3);
    }
}
