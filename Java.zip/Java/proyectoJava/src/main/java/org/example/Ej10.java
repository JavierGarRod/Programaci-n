package org.example;

public class Ej10 {
    static void main() {
        Scanner sc = new Scanner(System.in);
        int num1=sc.nextInt("Introduce un número: ");
        int num2=sc.nextInt("Introduce otro número: ");
        if (num1<0){
            System.out.println("Un número es menor que 0");
        }
        else{
            System.out.println(num1/num2);
        }
    }
}
